/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class Penduduk {

    public int nik;
    public String nama, alamat, jenisK;

    public Penduduk(int NIK, String nm, String al, String jk) {
        nik = NIK;
        nama = nm;
        alamat = al;
        jenisK = jk;
    }
}
