/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class nasabah {
    String noRekening,nama;
    
public nasabah(String noRek,String nm){
    noRekening=noRek;
    nama = nm;
}

    
public void nasabah(){

}
void print(){
        System.out.println("Nama = "+nama);
        System.out.println("Nomor Rekening = "+noRekening);
        
    
}   
}
